/*
 * Copyright (c) 2026, Aidan <JcbbcEnjoyer>
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
*/
#include "world.h"
#include "generator/chunk_gen.h"
#include "debug_generator/debug_generator.h"

// Attempt to advance a chunk from Lighting -> Lit once its own BFS and its
// (+X, +Z, +X+Z) neighbours' BFS have all fully drained.
// This replicates Beta's asymmetric convention: a chunk at (X,Z) is "owned"
// by its southwest corner, so only the three neighbors whose light bleeds
// into the +X/+Z edges need to have settled before we can send safely.
// Must be called with chunksMutex held.
void WorldManager::tryMarkLit(ChunkPos pos) {
    auto isSettled = [&](ChunkPos p) -> bool {
        auto* c = getChunkRaw(p);
        return c && c->neighborPropagated;
        };

    auto tryOne = [&](ChunkPos p) {
        auto* c = getChunkRaw(p);
        if (!c || c->state.load() != ChunkState::Lighting) return;
        if (!isSettled(p))              return;
        if (!isSettled({ p.x + 1, p.z })) return;
        if (!isSettled({ p.x, p.z + 1 })) return;
        if (!isSettled({ p.x + 1, p.z + 1 })) return;
        c->state.store(ChunkState::Lit, std::memory_order_release);
        };

    // A newly-settled chunk can unblock itself and the 3 neighbors that
    // were waiting on it to complete their own southwest-corner check.
    tryOne(pos);
    tryOne({ pos.x - 1, pos.z });
    tryOne({ pos.x,     pos.z - 1 });
    tryOne({ pos.x - 1, pos.z - 1 });
}

// Background lighting thread
void WorldManager::lightWorker() {
    while (lightThreadRunning) {
        std::vector<LightUpdate> batch;
        {
            std::unique_lock llock(lightMutex);
            lightCV.wait(llock, [this] {
                return !lightQueue.empty() || !lightThreadRunning;
                });
            if (!lightThreadRunning) break;

            int limit = std::min(int(lightQueue.size()), 4096);
            batch.reserve(limit);
            for (int i = 0; i < limit; ++i) {
                batch.push_back(lightQueue.front());
                lightQueue.pop_front();
            }
        }

        for (auto& upd : batch) {
            if (upd.y < 0 || upd.y >= CHUNK_HEIGHT) continue;

            std::lock_guard lock(chunksMutex);

            ChunkPos cp{ upd.x >> 4, upd.z >> 4 };
            auto* chunk = getChunkRaw(cp);
            if (!chunk || chunk->state.load() < ChunkState::Lighting) {
                // Update is stale (chunk unloaded or not yet lighting); just
                // decrement so the counter doesn't leak.
                if (chunk) chunk->pendingLightUpdates.fetch_sub(1, std::memory_order_relaxed);
                continue;
            }

            Int3 lp{ upd.x & 15, upd.y, upd.z & 15 };
            BlockType blockType = chunk->getBlock(lp);
            int opacity = std::max(1, int(Blocks::blockProperties[blockType].lightOpacity));
            int newVal = 0;
            bool changed = false;

            if (upd.isSkyLight) {
                if (chunk->canBlockSeeSky(lp)) {
                    newVal = 15;
                }
                else if (opacity < 15) {
                    auto getSky = [&](int x, int y, int z) -> int {
                        if (y >= CHUNK_HEIGHT) return 15;
                        if (y < 0) return 0;
                        auto* c = getChunkRaw({ x >> 4, z >> 4 });
                        return c ? c->getSkyLight({ x & 15, y, z & 15 }) : 0;
                        };
                    int best = 0;
                    best = std::max(best, getSky(upd.x - 1, upd.y, upd.z));
                    best = std::max(best, getSky(upd.x + 1, upd.y, upd.z));
                    best = std::max(best, getSky(upd.x, upd.y - 1, upd.z));
                    best = std::max(best, getSky(upd.x, upd.y + 1, upd.z));
                    best = std::max(best, getSky(upd.x, upd.y, upd.z - 1));
                    best = std::max(best, getSky(upd.x, upd.y, upd.z + 1));
                    newVal = std::max(0, best - opacity);
                }
                int oldVal = chunk->getSkyLight(lp);
                if (oldVal != newVal) { chunk->setSkyLight(lp, uint8_t(newVal)); changed = true; }
            }
            else {
                int emitted = int(Blocks::blockProperties[blockType].lightEmission);
                if (opacity < 15) {
                    auto getBlock = [&](int x, int y, int z) -> int {
                        if (y < 0 || y >= CHUNK_HEIGHT) return 0;
                        auto* c = getChunkRaw({ x >> 4, z >> 4 });
                        return c ? c->getBlockLight({ x & 15, y, z & 15 }) : 0;
                        };
                    int best = 0;
                    best = std::max(best, getBlock(upd.x - 1, upd.y, upd.z));
                    best = std::max(best, getBlock(upd.x + 1, upd.y, upd.z));
                    best = std::max(best, getBlock(upd.x, upd.y - 1, upd.z));
                    best = std::max(best, getBlock(upd.x, upd.y + 1, upd.z));
                    best = std::max(best, getBlock(upd.x, upd.y, upd.z - 1));
                    best = std::max(best, getBlock(upd.x, upd.y, upd.z + 1));
                    newVal = std::max(emitted, best - opacity);
                }
                else {
                    newVal = emitted;
                }
                int oldVal = chunk->getBlockLight(lp);
                if (oldVal != newVal) { chunk->setBlockLight(lp, uint8_t(newVal)); changed = true; }
            }

            if (changed) {
                int expected = std::max(0, newVal - 1);
                const int dx[] = { -1,1, 0,0, 0,0 };
                const int dy[] = { 0,0,-1,1, 0,0 };
                const int dz[] = { 0,0, 0,0,-1,1 };
                for (int i = 0; i < 6; ++i) {
                    int nx = upd.x + dx[i], ny = upd.y + dy[i], nz = upd.z + dz[i];
                    if (ny < 0 || ny >= CHUNK_HEIGHT) continue;
                    ChunkPos ncp{ nx >> 4, nz >> 4 };
                    auto* nc = getChunkRaw(ncp);
                    if (!nc || nc->state.load() < ChunkState::Lighting) continue;
                    Int3 nlp{ nx & 15, ny, nz & 15 };
                    int cur = upd.isSkyLight ? nc->getSkyLight(nlp) : nc->getBlockLight(nlp);
                    if (cur != expected) {
                        // Increment before pushing so the counter is never
                        // transiently zero while the update is in-flight.
                        nc->pendingLightUpdates.fetch_add(1, std::memory_order_relaxed);
                        std::lock_guard llock(lightMutex);
                        lightQueue.push_back({ nx, ny, nz, upd.isSkyLight });
                        lightCV.notify_one();
                    }
                }
            }

            // Decrement after all potential child updates are enqueued so we
            // never see a spurious zero while children are still being added.
            int remaining = chunk->pendingLightUpdates.fetch_sub(1, std::memory_order_acq_rel) - 1;
            if (remaining == 0 && !chunk->neighborPropagated) {
                chunk->neighborPropagated = true;
                tryMarkLit(cp);
            }
        }
    }
}

// Tick
void WorldManager::tick(const std::vector<ClientPosition>& players) {
    elapsed_ticks++;
    updateLoadRadius(players);
    pumpPipeline(players);
}

void WorldManager::updateLoadRadius(const std::vector<ClientPosition>& players) {
    std::unordered_set<ChunkPos> wanted;
    for (const auto& player : players) {
        Int2 center = player.getChunkPos();
        for (int dx = -VIEW_RADIUS; dx <= VIEW_RADIUS; dx++)
            for (int dz = -VIEW_RADIUS; dz <= VIEW_RADIUS; dz++)
                wanted.insert({ center.x + dx, center.z + dz });
    }

    std::lock_guard lock(chunksMutex);

    for (const auto& pos : wanted) {
        if (!chunks.contains(pos)) {
            auto c = std::make_unique<Chunk>();
            c->cpos = pos;
            chunks.emplace(pos, std::move(c));
        }
    }

    for (auto it = chunks.begin(); it != chunks.end(); ) {
        if (wanted.contains(it->first)) { ++it; continue; }
        ChunkState s = it->second->state.load();
        if (s == ChunkState::Generating || s == ChunkState::Poulating || s == ChunkState::Lighting) {
            ++it;
            continue;
        }
        it = chunks.erase(it);
    }
}

void WorldManager::pumpPipeline(const std::vector<ClientPosition>& players) {
    // Snapshot all chunk positions while holding the lock.
    std::vector<ChunkPos> snapshot;
    {
        std::lock_guard lock(chunksMutex);
        snapshot.reserve(chunks.size());
        for (auto& [pos, chunk] : chunks)
            snapshot.push_back(pos);
    }

    // --- Per-player generation budget ---
    // Total budget is fixed at MAX_GENERATIONS_PER_TICK. Each player gets an
    // equal slice so no single player can starve others during initial load.
    // If there are no players we still allow the full budget (e.g. pre-warming).
    constexpr int MAX_GENERATIONS_PER_TICK = 8;
    const int playerCount = static_cast<int>(players.size());
    const int slicePerPlayer = (playerCount > 0)
        ? std::max(1, MAX_GENERATIONS_PER_TICK / playerCount)
        : MAX_GENERATIONS_PER_TICK;

    // Build a sorted candidate list for each player: only Unloaded chunks,
    // ordered by chebyshev distance from that player's chunk position.
    // We'll round-robin across players, spending each player's slice before
    // moving on, so every player makes equal forward progress each tick.
    std::vector<std::vector<ChunkPos>> perPlayerQueues;
    perPlayerQueues.reserve(playerCount);

    for (const auto& player : players) {
        Int2 centre = player.getChunkPos();
        std::vector<ChunkPos> candidates;
        candidates.reserve(snapshot.size());

        {
            std::lock_guard lock(chunksMutex);
            for (const ChunkPos& p : snapshot) {
                auto it = chunks.find(p);
                if (it == chunks.end()) continue;
                if (it->second->state.load(std::memory_order_acquire) != ChunkState::Unloaded) continue;
                candidates.push_back(p);
            }
        }

        std::sort(candidates.begin(), candidates.end(), [&](const ChunkPos& a, const ChunkPos& b) {
            int da = std::max(std::abs(a.x - centre.x), std::abs(a.z - centre.z));
            int db = std::max(std::abs(b.x - centre.x), std::abs(b.z - centre.z));
            return da < db;
            });

        perPlayerQueues.push_back(std::move(candidates));
    }

    // Fallback for zero-player case: sort by distance from origin.
    std::vector<ChunkPos> noPlayerCandidates;
    if (playerCount == 0) {
        {
            std::lock_guard lock(chunksMutex);
            for (const ChunkPos& p : snapshot) {
                auto it = chunks.find(p);
                if (it == chunks.end()) continue;
                if (it->second->state.load(std::memory_order_acquire) != ChunkState::Unloaded) continue;
                noPlayerCandidates.push_back(p);
            }
        }
        std::sort(noPlayerCandidates.begin(), noPlayerCandidates.end(), [](const ChunkPos& a, const ChunkPos& b) {
            return (a.x * a.x + a.z * a.z) < (b.x * b.x + b.z * b.z);
            });
    }

    // Kick off generation jobs, respecting each player's slice.
    // A chunk already kicked off by one player's slice is skipped for others
    // (state will no longer be Unloaded by the time we check).
    std::unordered_set<ChunkPos> startedThisTick;

    auto startGeneration = [&](const ChunkPos& pos) -> bool {
        if (startedThisTick.contains(pos)) return false;
        std::lock_guard lock(chunksMutex);
        auto it = chunks.find(pos);
        if (it == chunks.end()) return false;
        if (it->second->state.load(std::memory_order_acquire) != ChunkState::Unloaded) return false;
        it->second->state.store(ChunkState::Generating, std::memory_order_release);
        std::shared_ptr<Chunk> chunkRef = it->second;
        pool.detach_task([chunkRef, this]() {
            thread_local Generator tl_gen(this->seed);
            tl_gen.GenerateChunk(*chunkRef);
            //DebugGenerator::generateChunk(*chunkRef);
            chunkRef->generateSkylightMap();
            chunkRef->isModified = true;
            {
                std::lock_guard lock(chunksMutex);
                flushPendingBlocks(chunkRef->cpos);
            }
            chunkRef->state.store(ChunkState::Generated, std::memory_order_release);
            });
        startedThisTick.insert(pos);
        return true;
        };

    if (playerCount == 0) {
        int started = 0;
        for (const ChunkPos& pos : noPlayerCandidates) {
            if (started >= MAX_GENERATIONS_PER_TICK) break;
            if (startGeneration(pos)) ++started;
        }
    }
    else {
        std::vector<int> cursors(playerCount, 0);
        int totalStarted = 0;
        const int totalBudget = slicePerPlayer * playerCount;
        bool anyProgress = true;
        while (totalStarted < totalBudget && anyProgress) {
            anyProgress = false;
            for (int i = 0; i < playerCount && totalStarted < totalBudget; ++i) {
                int playerStarted = static_cast<int>(
                    std::count_if(startedThisTick.begin(), startedThisTick.end(),
                        [&](const ChunkPos&) { return true; }) // placeholder; tracked below
                    );
                // Count how many this player has consumed via their own cursor progress.
                // Simpler: just give each player up to slicePerPlayer from their sorted list.
                int& cur = cursors[i];
                int playerConsumed = 0;
                while (playerConsumed < slicePerPlayer && cur < static_cast<int>(perPlayerQueues[i].size())) {
                    if (startGeneration(perPlayerQueues[i][cur])) {
                        ++playerConsumed;
                        ++totalStarted;
                        anyProgress = true;
                    }
                    ++cur;
                }
            }
        }
    }

    // Population and lighting seeding are not budgeted — they're cheap
    // (population is async, lighting seed just queues BFS work) and we
    // don't want generated chunks sitting idle waiting for a slot.
    for (const ChunkPos& pos : snapshot) {
        // Population
        {
            std::lock_guard lock(chunksMutex);
            auto it = chunks.find(pos);
            if (it != chunks.end() &&
                (it->second->state.load(std::memory_order_acquire) == ChunkState::Generated)) {
#ifdef POPULATION_ENABLED
                for (ChunkPos candidate : {
                    pos,
                        ChunkPos{ pos.x - 1, pos.z },
                        ChunkPos{ pos.x,     pos.z - 1 },
                        ChunkPos{ pos.x - 1, pos.z - 1 }
                })
                {
                    if (!canPopulateLocked(candidate)) continue;
                    auto cit = chunks.find(candidate);
                    if (cit == chunks.end()) continue;
                    cit->second->state.store(ChunkState::Poulating, std::memory_order_release);
                    std::shared_ptr<Chunk> chunkRef = cit->second;
                    pool.detach_task([chunkRef, this]() {
                        thread_local Generator tl_gen(this->seed);
                        tl_gen.PopulateChunk(*chunkRef, *this);
                        chunkRef->isTerrainPopulated = true;
                        chunkRef->isModified = true;
                        chunkRef->state.store(ChunkState::Populated, std::memory_order_release);
                        });
                    break;
                }
#else
                it->second->isTerrainPopulated = true;
                it->second->state.store(ChunkState::Populated, std::memory_order_release);
#endif
            }
        }

        // Seed lighting after population
        {
            std::lock_guard lock(chunksMutex);
            auto it = chunks.find(pos);
            std::shared_ptr<Chunk> chunkRef = it->second;
            if (chunkRef->state.load(std::memory_order_acquire) == ChunkState::Populated) {
                seedChunkLighting(pos);
                chunkRef->state.store(ChunkState::Lighting, std::memory_order_release);
            }
        }
    }
}