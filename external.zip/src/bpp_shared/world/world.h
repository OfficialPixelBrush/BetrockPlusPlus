/*
 * Copyright (c) 2026, Aidan <JcbbcEnjoyer>
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
*/

// The world manager acts like a wrapper around the chunk manager and lighting manager.
// It handles all world-related operations and provides a simple interface for the rest of the code to interact with the world.
// WorldManager.h
#pragma once
#include "base_structs.h"
#include "blocks.h"
#include "world/chunk.h"
#include "world/client_pos.h"
#include "BS_thread_pool.hpp"
#include <cstdint>
#include <unordered_map>
#include <unordered_set>
#include <mutex>
#include <condition_variable>
#include <memory>
#include <vector>
#include <deque>
#include <thread>
#include <atomic>

struct PendingBlock {
    Block block{ BLOCK_AIR, 0 };
    Int3 block_pos{ 0, 0, 0 };
};

// A single BFS lighting update -- world space coordinates.
struct LightUpdate {
    int x, y, z;
    bool isSkyLight; // true = sky light, false = block light
};

struct WorldManager {
    std::unordered_map<ChunkPos, std::shared_ptr<Chunk>> chunks;
    std::unordered_map<ChunkPos, std::vector<PendingBlock>> pending_blocks;
    std::mutex chunksMutex;

    // Lighting BFS queue -- seeded by the pipeline lighting stage and by
    // setBlock. Drained continuously by the background lighting thread.
    // Protected by lightMutex.
    std::deque<LightUpdate> lightQueue;
    std::mutex              lightMutex;
    std::condition_variable lightCV;

    BS::thread_pool<> pool{ std::max(1u, uint32_t(float(std::thread::hardware_concurrency()) * 0.25f)) };

    int64_t seed = 0;
    int64_t elapsed_ticks = 0;

    WorldManager() {
        lightThreadRunning = true;
        lightThread = std::thread(&WorldManager::lightWorker, this);
    }

    ~WorldManager() {
        lightThreadRunning = false;
        lightCV.notify_all();
        if (lightThread.joinable())
            lightThread.join();
    }

    void tick(const std::vector<ClientPosition>& players);
    int getViewRadius() { return VIEW_RADIUS; }
    int getSimulationDistance() { return SIMULATION_RADIUS; }

    // Public chunk accessor (acquires lock)
    std::shared_ptr<Chunk> getChunk(ChunkPos pos) {
        std::lock_guard lock(chunksMutex);
        return getChunkLocked(pos);
    }

    bool canPopulate(ChunkPos pos) {
        std::lock_guard lock(chunksMutex);
        return canPopulateLocked(pos);
    }

    BlockType getBlockId(Int3 wpos) {
        std::lock_guard lock(chunksMutex);
        auto* chunk = getChunkRaw({ wpos.x >> 4, wpos.z >> 4 });
        if (!chunk || chunk->state.load() < ChunkState::Generated)
            return BlockType::BLOCK_AIR;
        return chunk->getBlock({ wpos.x & 15, wpos.y, wpos.z & 15 });
    }

    uint8_t getMetadata(Int3 wpos) {
        std::lock_guard lock(chunksMutex);
        auto* chunk = getChunkRaw({ wpos.x >> 4, wpos.z >> 4 });
        if (!chunk || chunk->state.load() < ChunkState::Generated) return 0;
        return chunk->getMeta({ wpos.x & 15, wpos.y, wpos.z & 15 });
    }

    void setBlock(Int3 wpos, BlockType block_type, uint8_t metadata = 0) {
        std::lock_guard lock(chunksMutex);
        ChunkPos cp{ wpos.x >> 4, wpos.z >> 4 };
        auto* chunk = getChunkRaw(cp);
        if (!chunk || chunk->state.load() < ChunkState::Generated) {
            pending_blocks[cp].push_back({
                .block = Block{.type = block_type, .data = metadata },
                .block_pos = { wpos.x & 15, wpos.y, wpos.z & 15 }
                });
            return;
        }
        Int3 local{ wpos.x & 15, wpos.y, wpos.z & 15 };
        chunk->setBlock(local, block_type);
        chunk->setMeta(local, metadata);
        // Schedule lighting updates for the changed block and its 6 neighbors
        scheduleLightUpdates(wpos.x, wpos.y, wpos.z);
    }

    bool isAirBlock(Int3 wpos) {
        return getBlockId(wpos) == BlockType::BLOCK_AIR;
    }

    Material getMaterial(Int3 wpos) {
        return Blocks::blockProperties[getBlockId(wpos)].material;
    }

    bool isBlockNormalCube(Int3 wpos) {
        BlockType block = getBlockId(wpos);
        if (block == BlockType::BLOCK_AIR) return false;
        const auto& props = Blocks::blockProperties[block];
        return props.material.isSolid && props.isNormalCube;
    }

    int findTopSolidBlock(int wx, int wz) {
        std::lock_guard lock(chunksMutex);
        auto* chunk = getChunkRaw({ wx >> 4, wz >> 4 });
        if (!chunk || chunk->state.load() < ChunkState::Generated) return -1;
        int lx = wx & 15, lz = wz & 15;
        for (int y = 127; y > 0; --y) {
            BlockType block = chunk->getBlock({ lx, y, lz });
            if (block == BlockType::BLOCK_AIR) continue;
            Material mat = Blocks::blockProperties[block].material;
            if (mat.isSolid || mat.isLiquid) return y + 1;
        }
        return -1;
    }

    int getHeightValue(int wx, int wz) {
        std::lock_guard lock(chunksMutex);
        auto* chunk = getChunkRaw({ wx >> 4, wz >> 4 });
        if (!chunk || chunk->state.load() < ChunkState::Generated) return 0;
        return chunk->getHeightValue({ wx & 15, wz & 15 });
    }

    // Must be called with chunksMutex held.
    void flushPendingBlocks(ChunkPos pos) {
        auto pit = pending_blocks.find(pos);
        if (pit == pending_blocks.end()) return;
        auto* chunk = getChunkRaw(pos);
        if (!chunk) return;
        for (auto& pb : pit->second) {
            chunk->setBlock(pb.block_pos, pb.block.type);
            chunk->setMeta(pb.block_pos, pb.block.data);
        }
        pending_blocks.erase(pit);
    }

    // Seeds the light queue for a newly-Lit chunk.
    // Must be called with chunksMutex held.
    void seedChunkLighting(ChunkPos pos) {
        auto* chunk = getChunkRaw(pos);
        if (!chunk) return;

        int bx = pos.x * CHUNK_WIDTH;
        int bz = pos.z * CHUNK_WIDTH;

        std::vector<LightUpdate> seeds;

        // Block light emitters inside this chunk
        for (int x = 0; x < CHUNK_WIDTH; ++x)
            for (int z = 0; z < CHUNK_WIDTH; ++z)
                for (int y = 0; y < CHUNK_HEIGHT; ++y) {
                    BlockType b = chunk->getBlock({ x, y, z });
                    if (Blocks::blockProperties[b].lightEmission > 0)
                        seeds.push_back({ bx + x, y, bz + z, false });
                }

        // Border columns with each cardinal neighbor.
        const int ndx[] = { -1, 1,  0, 0 };
        const int ndz[] = { 0, 0, -1, 1 };
        for (int i = 0; i < 4; ++i) {
            auto* neighbor = getChunkRaw({ pos.x + ndx[i], pos.z + ndz[i] });
            if (!neighbor) {
                std::cout << "Big no no!";
                continue; // shouldn't happen given stage 4 check
            }

            int nbx = (pos.x + ndx[i]) * CHUNK_WIDTH;
            int nbz = (pos.z + ndz[i]) * CHUNK_WIDTH;

            for (int t = 0; t < CHUNK_WIDTH; ++t) {
                int lx = (ndx[i] == -1) ? 0 : (ndx[i] == 1) ? CHUNK_WIDTH - 1 : t;
                int lz = (ndz[i] == -1) ? 0 : (ndz[i] == 1) ? CHUNK_WIDTH - 1 : t;
                int nlx = (ndx[i] == -1) ? CHUNK_WIDTH - 1 : (ndx[i] == 1) ? 0 : lx;
                int nlz = (ndz[i] == -1) ? CHUNK_WIDTH - 1 : (ndz[i] == 1) ? 0 : lz;

                int thisH = chunk->getHeightValue({ lx, lz });
                int neighborH = neighbor->getHeightValue({ nlx, nlz });
                int topY = std::max(thisH, neighborH);

                // Sky light -- seed both sides of the border up to the surface
                for (int y = 0; y <= topY; ++y) {
                    seeds.push_back({ bx + lx,  y, bz + lz,  true });
                    seeds.push_back({ nbx + nlx, y, nbz + nlz, true });
                }

                // Block light -- seed border columns that have any block light
                for (int y = 0; y < CHUNK_HEIGHT; ++y) {
                    if (chunk->getBlockLight({ lx, y, lz }) > 0)
                        seeds.push_back({ nbx + nlx, y, nbz + nlz, false });
                    if (neighbor->getBlockLight({ nlx, y, nlz }) > 0)
                        seeds.push_back({ bx + lx, y, bz + lz, false });
                }
            }
        }

        if (!seeds.empty()) {
            // Tally how many updates land in each chunk so the BFS counter
            // starts at the right value before the worker thread sees them.
            std::cout << "Seeded " << seeds.size() << " lights.\n";
            for (auto& s : seeds) {
                auto* c = getChunkRaw({ s.x >> 4, s.z >> 4 });
                if (c) c->pendingLightUpdates.fetch_add(1, std::memory_order_relaxed);
            }
            std::lock_guard llock(lightMutex);
            for (auto& s : seeds)
                lightQueue.push_back(s);
            lightCV.notify_one();
        }
    }

private:
    static constexpr int VIEW_RADIUS = 15;
    static constexpr int SIMULATION_RADIUS = 9;

    // Background lighting thread
    std::thread       lightThread;
    std::atomic<bool> lightThreadRunning{ false };

    // The lighting thread loop; runs BFS continuously in the background.
    void lightWorker();

    // Schedule sky+block light updates for a changed block and its neighbors.
    // Must be called with lightMutex held OR before lightThread starts.
    void scheduleLightUpdates(int wx, int wy, int wz) {
        const int offsets[7][3] = {
            {0,0,0},{-1,0,0},{1,0,0},{0,-1,0},{0,1,0},{0,0,-1},{0,0,1}
        };
        std::lock_guard llock(lightMutex);
        for (auto& o : offsets) {
            lightQueue.push_back({ wx + o[0], wy + o[1], wz + o[2], true });
            lightQueue.push_back({ wx + o[0], wy + o[1], wz + o[2], false });
        }
        lightCV.notify_one();
    }

    void updateLoadRadius(const std::vector<ClientPosition>& players);
    void pumpPipeline(const std::vector<ClientPosition>& players);
    void tryMarkLit(ChunkPos pos); // chunksMutex must be held by caller

    Chunk* getChunkRaw(ChunkPos pos) {
        auto it = chunks.find(pos);
        return (it != chunks.end()) ? it->second.get() : nullptr;
    }

    std::shared_ptr<Chunk> getChunkLocked(ChunkPos pos) {
        auto it = chunks.find(pos);
        return (it != chunks.end()) ? it->second : nullptr;
    }

    bool canPopulateLocked(ChunkPos pos) {
        auto* chunk = getChunkRaw(pos);
        if (!chunk) return false;
        if (chunk->isTerrainPopulated) return false;
        if (chunk->state.load() < ChunkState::Generated) return false;
        auto* a = getChunkRaw({ pos.x + 1, pos.z });
        auto* b = getChunkRaw({ pos.x,     pos.z + 1 });
        auto* c = getChunkRaw({ pos.x + 1, pos.z + 1 });
        if (!a || !b || !c) return false;
        if (a->state.load() < ChunkState::Generated) return false;
        if (b->state.load() < ChunkState::Generated) return false;
        if (c->state.load() < ChunkState::Generated) return false;
        return true;
    }
};